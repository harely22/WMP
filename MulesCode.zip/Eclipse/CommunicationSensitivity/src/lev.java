import java.io.IOException;
import java.util.Scanner;

public class lev {

	public static void main(String[] args) throws InterruptedException, IOException {
		System.out.println("Please enter your age:");
		Scanner in = new Scanner(System.in);
		int j = in.nextInt();
		System.out.println("Your age is:"+j);
		if(j<4){
			System.out.println("You are cute");
		}
		else
		{
			System.out.println("You are big");
		}
//		for(int i=1;i<=6;i++){
//System.out.println(i+". Lev the dragon!!!!!!");
//Thread.sleep(1000);
//		}
//	
//	
//	for(int i=1;i<=6;i++){
//System.out.println(i+". Lev T-REX!!!!!!");
//Thread.sleep(1000);
//		}
	

}
}
