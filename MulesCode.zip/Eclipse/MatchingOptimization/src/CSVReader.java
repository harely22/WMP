import java.awt.List;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CSVReader {



	private ArrayList<int[]> rowList = new ArrayList<int[]>(); 
	private int[] intRow;
	private int[][] prefMatrix;

	public void readCSVFile(String fileName){
		String csvFile= fileName;

		String line = "";
		String cvsSplitBy = ",";

		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			int rowCounter=0;
			while ((line = br.readLine()) != null) {

				// use comma as separator
				String[] row = line.split(cvsSplitBy);
				intRow=new int[row.length];
				int duplicateRow=Integer.parseInt(row[0]);
				for(int j=0;j<duplicateRow;j++){
					rowCounter++;
					System.out.print("row "+rowCounter+" = ");
					for(int i=0;i<row.length;i++){
						System.out.print(row[i] + ",");
						if(i!=0){
							intRow[i]=Integer.parseInt(row[i]);
						}
					}
					System.out.println();
				}
				rowList.add(intRow);
			}
			System.out.println("raw data has "+rowCounter+" rows ");
			System.out.println("each row has "+intRow.length+" entries ");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void createPrefMatrix(){

		prefMatrix=new int[rowList.size()][rowList.size()];
		for(int i=0;i<rowList.size();i++){

			int[] currentRow=rowList.get(i);
			for(int j=0;j<rowList.size();j++){
				if(i==j)continue;
				int[] otherRow=rowList.get(j);

				prefMatrix[i][j]=calculateDiff(currentRow,otherRow);

			}
			System.out.println();
		}
	}

	private int calculateDiff(int[]  row1, int[] row2){
		int diff=0;
		int weight=row1.length;
		for(int i=0;i<row1.length;i++){
			int currentValue=row1[i];
			for(int j=0;j<row2.length;j++){
				if(row2[j]==currentValue){
					int addition=Math.abs(i-j)*(weight-i);
					System.out.println("addition for " +i+","+j+"="+addition);

				diff+=addition;
				}
			}
		}
		return diff;
	}
	public void printPrefMatrix(){
		for(int i=0;i<prefMatrix.length;i++){
			System.out.print("row "+i+ "\t");
			for(int j=0;j<rowList.size();j++){
				System.out.print(prefMatrix[i][j]+"\t");

				}
			System.out.println();
			}
		
	}

	public static void main(String[] args) {

		String csvFile = "C:/Users/Harel/Dropbox/PostDoc/Stable Matching Hua/Optimization/sushi3.csv";
		CSVReader reader=new CSVReader();
		reader.readCSVFile(csvFile);
		reader.createPrefMatrix();
		reader.printPrefMatrix();
	}

}