

public  class Grid {
	
	 public int MAX_X;
	 public int MAX_Y;

	public Grid(int x, int y){
		MAX_X=x;
		MAX_Y=y;
	}
	
}