import java.util.Random;

public class NormalDistribution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double durationMean=100;
		double durationStDev=durationMean/10;
		Random rand=new Random();
		double val;
		double minval=durationMean;
		double avgval=0;
		for(int DurationsCounter=0;DurationsCounter<1000;DurationsCounter++){
	//		durationMean=10*DurationsCounter;
	//		durationMean=100;
			val = durationMean +rand.nextGaussian() * durationStDev;
	//		System.out.println("normal dist with mean "+durationMean+" and stdev="+durationStDev+" ="+val);
			if(val<minval){
				minval=val;
			}
			avgval+=val;
		}
		
		System.out.println("normal dist with mean "+durationMean+" and stdev="+durationStDev+" minval="+minval+ " avgval="+avgval/1000);
		System.out.println();
		System.out.println();

//log normal
		avgval=0;
		Random rng = new Random(0);
		double stdNormal;
		double normalValue;
		//exp(-0.5 * ((ln(x) - m) / s)^2) / (s * sqrt(2 * pi) * x)
		double stddev=0.1;
		double mean=Math.log(durationMean);
		double[] logNormalValues = new double[1000];
		minval=durationMean;
		for (int i = 0; i < 1000; ++i)
		{
		    stdNormal   = rng.nextGaussian();
		    normalValue = stddev*stdNormal + mean;

		    logNormalValues[i] = Math.exp(normalValue);
//			System.out.println("lognormal dist with mean "+mean+" and stdev="+stddev+" ="+logNormalValues[i]+" normal val="+normalValue);
		    if(logNormalValues[i]<minval){
				minval=logNormalValues[i];
			}
		    avgval+=logNormalValues[i];
		}
		
	
	System.out.println("lognormal dist with mean "+mean+" and stdev="+stddev+"  minval="+minval+ " avgval="+avgval/1000);
	}
//	data lognormal;
//	call streaminit(1);
//	keep x y;
//	m = 80; v = 225;      /* specify mean and variance of Y */
//	phi = sqrt(v + m**2);
//	mu    = log(m**2/phi);
//	sigma = sqrt(log(phi**2/m**2));
//	do i = 1 to 100000;
//	   x = rand('Normal', mu, sigma);
//	   y = exp(x);
//	   output;
//	end;
//	run;

}
